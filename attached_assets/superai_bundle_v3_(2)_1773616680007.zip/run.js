'use strict';
// Super AI Lab Bundle — auto-generated entry point
const fs = require('fs');
const path = require('path');
const entries = ['main.js','framework.js','index.js','capability_report.js'];
for (const e of entries) {
  const p = path.join(__dirname, 'src', e);
  if (fs.existsSync(p)) { console.log('Running ' + e + '...'); require(p); break; }
}