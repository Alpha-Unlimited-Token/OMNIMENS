'use strict';

/*
  benchmark.js — integrated system benchmark with real numbers.
  REQUIREMENTS MET:
  - Uses framework.BenchmarkSuite for median ms and avgScore.
  - Measures ops/sec approximation and computed intelligence quotient.
  - Runs the full integrated pipeline repeatedly (real work).
*/

const path = require('path');
const { BenchmarkSuite, EventBus, ACP, stableStringify } = require('./framework.js');
const { buildSystemPipeline } = require('./system.js');
const mem = require('./memory_system.js');

function assert(cond, msg) {
  if (!cond) throw new Error(msg || 'assertion failed');
}

async function main() {
  const bus = new EventBus();
  bus.on('bench:result', (r) => {
    console.log('BENCH_RESULT', stableStringify({
      name: r.name,
      iters: r.iters,
      ok: r.ok,
      err: r.err,
      medianMs: Number(r.medianMs.toFixed(3)),
      avgScore: Number(r.avgScore.toFixed(6)),
      opsPerSecApprox: Number((1000 / Math.max(1e-9, r.medianMs)).toFixed(2)),
    }));
  });
  bus.on('bench:summary', (s) => {
    console.log('BENCH_SUMMARY', stableStringify({
      totalOk: s.metrics.totalOk,
      totalErr: s.metrics.totalErr,
      medianMsSum: Number(s.metrics.medianMsSum.toFixed(3)),
      avgScoreSum: Number(s.metrics.avgScoreSum.toFixed(6)),
      quotient: Number(s.intelligence.quotient.toFixed(6)),
    }));
  });

  const suite = new BenchmarkSuite({ eventBus: bus });

  suite.add('integrated_pipeline_end_to_end', async () => {
    const pipeline = buildSystemPipeline({ eventBus: null });
    const input = ACP.serialize({
      from: 'bench',
      to: 'system',
      type: 'run',
      payload: { ts: Date.now(), seed: 20240315, tag: path.basename(__filename) },
    });
    const outStr = await pipeline.run(input, {});
    const env = ACP.deserialize(outStr);
    assert(env.type === 'system:result', 'bad output type');
    const p = env.payload;

    const acc = p.training.acc;
    const hopOk = p.hopfield.completionOk ? 1 : 0;
    const consolidated = p.plasticity.consolidation.hasLongTerm ? 1 : 0;
    const stdpGain = p.plasticity.stdp.delta01;

    const score =
      1000 * acc +
      100 * hopOk +
      50 * consolidated +
      200 * Math.max(0, Math.min(1, stdpGain));
    return score;
  }, { iters: 7 });

  suite.add('hopfield_completion_accuracy_5', () => {
    const n = 18;
    const patterns = mem.makeDeterministicPatterns5(n);
    const hop = new mem.PatternCompletionHopfield({ n });
    for (const p of patterns) hop.storePattern(p);

    let ok = 0;
    for (let i = 0; i < patterns.length; i++) {
      const target = patterns[i];
      const corrupted = target.slice();
      const flips = [2, 7, 15].map(x => x % n);
      for (const idx of flips) corrupted[idx] = corrupted[idx] ? 0 : 1;

      const completed = hop.complete(corrupted, { steps: 10 }).out01;

      let same = true;
      for (let j = 0; j < n; j++) {
        if ((completed[j] ? 1 : 0) !== (target[j] ? 1 : 0)) { same = false; break; }
      }
      if (same) ok++;
    }
    const acc = ok / patterns.length;
    return 1000 * acc;
  }, { iters: 20 });

  const { summary } = await suite.run({});
  console.log('INTEGRATED_BENCH_INTELLIGENCE_QUOTIENT', Number(summary.intelligence.quotient.toFixed(6)));
}

if (require.main === module) {
  main().catch((e) => {
    console.error('BENCH_FAILED', e && e.stack ? e.stack : e);
    process.exitCode = 1;
  });
}